
public class Problem6 {
	public static void main(String[] args) {
	
		int inputNumber = 15;
		
		int sumNumber = 0;
		
		for (int i = 1; i <= inputNumber; i++) {
			
			sumNumber += i;
		}
		
		System.out.println(sumNumber);
		
		
		
		
		
		
		
	}

}
