import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class Problem4 {

	public static void main(String[] args) {
		
         Scanner sc = new Scanner(System.in);
		
		int firstNumber = sc.nextInt();
		int secondNumber = sc.nextInt();
		
		
		ArrayList<Integer> euroList = new ArrayList<Integer>();
		euroList.add(firstNumber);
		euroList.add(secondNumber);
		Collections.sort(euroList);
		
		int num1 = euroList.get(0);
		int num2 = euroList.get(1);
		
		System.out.print(num1);
		System.out.println(num2);
		
		
		
		
		
		
		
		
		// TODO Auto-generated method stub

	}

}
