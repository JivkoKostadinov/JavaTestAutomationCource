
public class Computer {
	
	int year;
	int price;
	int hardDiskMemory;
	double freeMemory;
	boolean isNoteBook;
	String operationSystem;
	
	
	 void changeOperationSystem(String newOperationSystem){
		 
		 operationSystem = newOperationSystem;
	 
	 }
	
	
	 void useMemory(double memory){
		 
		 if (freeMemory < hardDiskMemory) {
			
			 freeMemory = freeMemory - memory;
		}else {
			
			System.out.println("Not enough free memory!");
			
		}
		 
	 }
	
	
}
