package Lecture7;

import java.util.Arrays;
import java.util.Scanner;

public class Problem1 {

	public static void main(String[] args) {
		//read from input
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of the array :");
		int number = sc.nextInt();
		System.out.println("Enter value of the element of the array :");
		
		//add input number in to array
		int [] arrayNumber = new int[number];
		
		for (int i = 0; i < arrayNumber.length; i++) {	
			
			arrayNumber[i] = sc.nextInt();
			
		}
		//add to array find number
		int [] arraySorted = new int[number];
		
		sc.close();
		
		for (int i = 0; i < arrayNumber.length; i++) {
			if (arrayNumber[i] % 3 == 0) {
				for (int j = 0; j < arraySorted.length; j++) {
					arraySorted[i]= arrayNumber[i];
					Arrays.sort( arraySorted );
				}
			}else {
	
				System.out.println("You do not have such number ");
			}
			
			
		}

		//print answer
		for (int i = 0; i < 1; i++) {
			
			if (arraySorted[i] != 0) {
				
				System.out.println("The smallest number divisible by 3 : " + arraySorted[0]);
			}else {
				
				System.out.println("You do not have such number ");
			}
			
			
		}
		
					
		}
		
		
		
		
		
		
		
		// TODO Auto-generated method stub

	}


