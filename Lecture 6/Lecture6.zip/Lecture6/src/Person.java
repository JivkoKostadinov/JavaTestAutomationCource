

public class Person  {

		
		protected  String name;
		protected  int age;
		protected  boolean isMan;
		
		Person(){
			this.name=name;
			this.age=age;
			this.isMan = isMan;
			
		}
		
		void showPersonInfo(){
			
			System.out.println(this.name);
			System.out.println(this.age);
			System.out.println(this.isMan);
			
			
			
			
		}
		

	}
