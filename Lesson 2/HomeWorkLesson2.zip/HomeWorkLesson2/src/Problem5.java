
public class Problem5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int numberOne = 9;
		int numberTwo = 15;
		
		for (int i = numberOne; i <= numberTwo; i++) {
			
			System.out.println(i);
			
		}
		
		
		
		
	}

}
